#Solution 2:#

install.packages("lpSolve")
install.packages("lpSolveAPI")
library(lpSolveAPI)


Manu_Model <- make.lp(0, 9) # 9 decision variables
lp.control(Manu_Model, sense= "maximize")
set.objfn(Manu_Model, c(25,10,5,21,6,1,25,10,5))

add.constraint(Manu_Model, c(1,1,1,0,0,0,0,0,0), "<=", 4200)
add.constraint(Manu_Model, c(0,0,0,1,1,1,0,0,0), "<=", 3200)
add.constraint(Manu_Model, c(0,0,0,0,0,0,1,1,1), "<=", 3500)
add.constraint(Manu_Model, c(0.5,-0.5,-0.5,0,0,0,0,0,0), ">=", 0)
add.constraint(Manu_Model, c(0,0,0,0.4,-0.6,-0.6,0,0,0), ">=", 0)
add.constraint(Manu_Model, c(0,0,0,0,0,0,0.6,-0.4,-0.4), ">=", 0)
add.constraint(Manu_Model, c(-0.4,0.6,-0.4,0,0,0,0,0,0), ">=", 0)
add.constraint(Manu_Model, c(0,0,0,-0.4,0.6,-0.4,0,0,0), ">=", 0)
add.constraint(Manu_Model, c(0,0,0,0,0,0,-0.5,0.5,-0.5), ">=", 0)

set.bounds(Manu_Model, lower = c(0,0), columns = c(1, 2))
# set.bounds(assemblyModel, upper = 40, columns = 1)

solve(Manu_Model) # http://lpsolve.sourceforge.net/5.5/solve.htm

get.objective(Manu_Model)
get.variables(Manu_Model)
get.constraints(Manu_Model) 

Manu_Model
```


```{r}
#Solution 3#
#Game for company no. 1


company1 <- make.lp(0, 6)

lp.control(company1, sense= "maximize")  

set.objfn(company1, c(0, 0, 0, 0, 0, 1))

add.constraint(company1, c(-1, -1, -1, -1, 1, 1), "<=", 0)
add.constraint(company1, c(1, -1, -1, -1, 1, 1), "<=", 0)
add.constraint(company1, c(1, 1, -1, -1, 1, 1), "<=", 0)
add.constraint(company1, c(1, 1, 1, -1, 1, 1), "<=", 0)
add.constraint(company1, c(1, 1, 1, 1, -1, 1), "<=", 0)
add.constraint(company1, c(1, 1, 1, 1, 1, 0), "=", 1)

set.bounds(company1, lower = c(0, 0, 0, 0, 0, -Inf))

Row_Name <- c("ROW#1", "ROW#2", "ROW#3","ROW#4", "ROW#5", "ROW#6")

Col_Name <- c("x1", "x2", "x3", "x4", "x5", "v")

dimnames(company1) <- list(Row_Name, Col_Name)

solve(company1) # http://lpsolve.sourceforge.net/5.5/solve.htm

get.objective(company1)

get.variables(company1)

get.constraints(company1)

company1